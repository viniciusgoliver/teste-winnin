export type JwtRole = 'USER' | 'ADMIN';

export interface JwtUser {
  sub: number; // userId
  email: string;
  role: JwtRole;
}
