export class CreateProductDTO {
  name!: string;
  price!: number;
  stock!: number;
}
