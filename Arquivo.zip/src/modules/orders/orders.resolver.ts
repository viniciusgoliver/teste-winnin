/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { Args, Mutation, Query, Resolver } from '@nestjs/graphql';
import { PlaceOrderUseCase } from '../../core/application/use-cases/place-order.usecase';
import { PlaceOrderInput } from './dto/place-order.input';
import { UseFilters, UseGuards } from '@nestjs/common';
import { DomainExceptionFilter } from '../../common/filters/domain-exception.filter';
import { Field, Float, Int, ObjectType } from '@nestjs/graphql';
import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { CurrentUser } from '../auth/decorators/current-user.decorator';

@ObjectType('Order')
class OrderGQL {
  @Field(() => Int) id!: number;
  @Field(() => Int) userId!: number;
  @Field(() => Float) total!: number;
  @Field() createdAt!: Date;
}

@Resolver(() => OrderGQL)
@UseFilters(DomainExceptionFilter)
@UseGuards(GqlAuthGuard, RolesGuard)
export class OrdersResolver {
  constructor(private placeOrderUC: PlaceOrderUseCase) {}

  @Mutation(() => OrderGQL)
  @Roles('USER', 'ADMIN')
  placeOrder(@Args('input') input: PlaceOrderInput, @CurrentUser() user: any) {
    return this.placeOrderUC.execute(user.sub, input.items);
  }

  @Query(() => [OrderGQL])
  @Roles('USER', 'ADMIN')
  orders() {
    return [];
  }
}
