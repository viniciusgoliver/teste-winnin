import { Args, Mutation, Query, Resolver } from '@nestjs/graphql';
import { CreateUserUseCase } from '../../core/application/use-cases/create-user.usecase';
import { ListUsersUseCase } from '../../core/application/use-cases/list-users.usecase';
import { CreateUserInput, RoleGQL } from './dto/create-user.input';
import { UseFilters, UseGuards } from '@nestjs/common';
import { DomainExceptionFilter } from '../../common/filters/domain-exception.filter';
import { Field, Int, ObjectType } from '@nestjs/graphql';

import { GqlAuthGuard } from '../auth/guards/gql-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';

@ObjectType('User')
class UserGQL {
  @Field(() => Int) id!: number;
  @Field() name!: string;
  @Field() email!: string;
  @Field(() => RoleGQL) role!: RoleGQL;
  @Field() createdAt!: Date;
}

@Resolver(() => UserGQL)
@UseFilters(DomainExceptionFilter)
export class UsersResolver {
  constructor(
    private createUserUC: CreateUserUseCase,
    private listUsersUC: ListUsersUseCase,
  ) {}

  @Mutation(() => UserGQL)
  @UseGuards(GqlAuthGuard, RolesGuard)
  @Roles('ADMIN')
  createUser(@Args('input') input: CreateUserInput) {
    return this.createUserUC.execute(input);
  }

  @Query(() => [UserGQL])
  users() {
    return this.listUsersUC.execute();
  }
}
